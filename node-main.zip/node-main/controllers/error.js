export const errorControllers = (req, res, next) => {
    console.log(`Render Error - errorControllers  status: ${req.status}`)
    res.status(404).render('404', {
        pageTitle: 'Page not found',    // vesszó a végére, mert új sort adtam hozz
        path: ''                        // beállítva a path
    })
}