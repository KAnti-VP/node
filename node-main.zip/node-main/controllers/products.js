import { products } from "../routes/admin.js"

export const getAddProduct = (req, res, next) => {
    res.render('add-product', {
      pageTitle: 'Add-product',
      path: '/admin/add-product'
    })
}

export const postAddProduct = (req, res, next) => {
  //   res.render('shop', {
  //     pageTitle: 'My products'
  // })     // helyett az alábbi:
  products.push( { title: req.body.title } )
  console.log(products)
  res.status(301).redirect('/')
}

export const getAllProducts = (req, res, next) => {
  res.render('shop.ejs',{       // törölve lett a )
    pageTitle:'shop',
    prods: products,
    path: '/'
  })                        // hiányzott a )
}