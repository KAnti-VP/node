import path from 'path'

export default path.dirname(process.require.main.filename)