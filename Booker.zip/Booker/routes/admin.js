import express from 'express'

import * as adminController from '../controllers/admin.js'

const router = express.Router()

// /admin/add-book => GET
router.get('/add-book', adminController.getAddBooks)

// /admin/books => GET
router.get('/books', adminController.getBooks)

// /admin/add-book => POST
router.post('/add-book', adminController.postAddBooks)

// /admin/edit-book/0.154875214 => GET
router.get('/edit-book/:bookId', adminController.getEditBooks)

// /admin/edit-book => POST
router.post('/edit-book', adminController.postEditBook)

// /admin/delete-book => DELETE
router.post('/delete-book', adminController.postDeleteBook)

export default router